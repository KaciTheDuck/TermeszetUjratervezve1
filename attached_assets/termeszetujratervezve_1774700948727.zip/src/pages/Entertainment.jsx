import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function createPageUrl(pageName) {
  return `/${pageName}`;
}

// entertainment page - fun stuff for hikers

export default function Entertainment() {
  const [showLinks, setShowLinks] = useState(false);
  const navigate = useNavigate();
  
  return (
    <div style={{ backgroundColor: "#DAD7CD", minHeight: "100vh", paddingBottom: "100px" }}>
      
      {/* header */}
      <div style={{ 
        backgroundImage: "url('https://images.unsplash.com/photo-1551632811-561732d1e306?w=1920&q=80')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        padding: "40px 20px 30px 20px"
      }}>
        <h1 style={{ color: "white", fontSize: "24px", margin: 0, textShadow: "0 2px 10px rgba(0,0,0,0.3)" }}>Szórakozás</h1>
        <p style={{ color: "rgba(255,255,255,0.9)", marginTop: "5px", textShadow: "0 2px 8px rgba(0,0,0,0.3)" }}>Feladatok és kihívások</p>
      </div>

      {/* content */}
      <div style={{ padding: "20px" }}>
        
        {/* nature explorer section */}
        <div style={{
          backgroundColor: "white",
          borderRadius: "15px",
          padding: "20px",
          boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
          marginBottom: "20px"
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: "15px", marginBottom: "15px" }}>
            <div style={{ fontSize: "30px" }}>🌿</div>
            <div>
              <h2 style={{ margin: 0, color: "#344E41", fontSize: "18px" }}>Fedezd fel a természetet</h2>
              <p style={{ margin: "5px 0 0 0", color: "#3A5A40", fontSize: "12px" }}>Bakancslistád és madármegfigyelés</p>
            </div>
          </div>

          <p style={{ color: "#666", fontSize: "14px", lineHeight: "1.6", marginBottom: "15px" }}>
            Fedezd fel a természet csodáit! Tudj meg többet a téged körülvevő környezetről
          </p>

          <button 
            onClick={() => navigate(createPageUrl('NatureExplorer'))}
            style={{
            width: "100%",
            padding: "12px",
            backgroundColor: "#3A5A40",
            color: "white",
            border: "none",
            borderRadius: "10px",
            cursor: "pointer",
            fontSize: "14px"
          }}>
            Felfedezés indítása
          </button>
        </div>

        {/* forest taste section */}
        <div style={{
          backgroundColor: "white",
          borderRadius: "15px",
          padding: "20px",
          boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
          marginBottom: "20px"
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: "15px", marginBottom: "15px" }}>
            <div style={{ fontSize: "30px" }}>🍃</div>
            <div>
              <h2 style={{ margin: 0, color: "#344E41", fontSize: "18px" }}>Erdő íze</h2>
              <p style={{ margin: "5px 0 0 0", color: "#3A5A40", fontSize: "12px" }}>Ehető növények és receptek</p>
            </div>
          </div>

          <p style={{ color: "#666", fontSize: "14px", lineHeight: "1.6", marginBottom: "15px" }}>
            Ismerj meg ehető növényeket és próbálj ki erdei recepteket a következő túrádon!
          </p>

          <button 
            onClick={() => navigate(createPageUrl('ForestTaste'))}
            style={{
            width: "100%",
            padding: "12px",
            backgroundColor: "#3A5A40",
            color: "white",
            border: "none",
            borderRadius: "10px",
            cursor: "pointer",
            fontSize: "14px"
          }}>
            Receptek megtekintése
          </button>
        </div>

        {/* water quality observation section */}
        <div style={{
          backgroundColor: "white",
          borderRadius: "15px",
          padding: "20px",
          boxShadow: "0 2px 10px rgba(0,0,0,0.1)"
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: "15px", marginBottom: "15px" }}>
            <div style={{ fontSize: "30px" }}>💧</div>
            <div>
              <h2 style={{ margin: 0, color: "#344E41", fontSize: "18px" }}>Vízminőség megfigyelése</h2>
              <p style={{ margin: "5px 0 0 0", color: "#3A5A40", fontSize: "12px" }}>Vizsgáld a vízminőséget</p>
            </div>
          </div>
          
          <p style={{ color: "#666", fontSize: "14px", lineHeight: "1.6", marginBottom: "15px" }}>
            Szeretnéd kideríteni hogy a túrautvonalad mentén található vízfolyás mennyire tiszta? Itt van a segítség! Kövesd a lépéseket, és tudd meg néhány perc alatt, mennyire egészséges a vízfolyás a túrád mentén!
          </p>
          
          <button style={{
            width: "100%",
            padding: "12px",
            backgroundColor: "#3A5A40",
            color: "white",
            border: "none",
            borderRadius: "10px",
            cursor: "pointer",
            fontSize: "14px"
          }}>
            Megfigyelés indítása
          </button>
          
          <div style={{ marginTop: "15px", display: "flex", gap: "10px", flexWrap: "wrap" }}>
            <div 
              onClick={() => navigate(createPageUrl('WaterQualitySteps'))}
              style={{
              flex: 1,
              minWidth: "45%",
              backgroundColor: "#A3B18A",
              padding: "10px",
              borderRadius: "8px",
              textAlign: "center",
              cursor: "pointer"
            }}>
              <div style={{ fontSize: "20px", marginBottom: "5px" }}>📝</div>
              <p style={{ margin: 0, fontSize: "11px", color: "#344E41" }}>Lépések</p>
            </div>
            <div style={{
              flex: 1,
              minWidth: "45%",
              backgroundColor: "#A3B18A",
              padding: "10px",
              borderRadius: "8px",
              textAlign: "center"
            }}>
              <div style={{ fontSize: "20px", marginBottom: "5px" }}>📷</div>
              <p style={{ margin: 0, fontSize: "11px", color: "#344E41" }}>Fényképek</p>
            </div>
            <div 
              onClick={() => navigate(createPageUrl('WaterQualityProtocol'))}
              style={{
              flex: 1,
              minWidth: "45%",
              backgroundColor: "#A3B18A",
              padding: "10px",
              borderRadius: "8px",
              textAlign: "center",
              cursor: "pointer"
            }}>
              <div style={{ fontSize: "20px", marginBottom: "5px" }}>📋</div>
              <p style={{ margin: 0, fontSize: "11px", color: "#344E41" }}>Jegyzőkönyv</p>
            </div>
            <div 
              onClick={() => navigate(createPageUrl('TaskSheet'))}
              style={{
              flex: 1,
              minWidth: "45%",
              backgroundColor: "#A3B18A",
              padding: "10px",
              borderRadius: "8px",
              textAlign: "center",
              cursor: "pointer"
            }}>
              <div style={{ fontSize: "20px", marginBottom: "5px" }}>📝</div>
              <p style={{ margin: 0, fontSize: "11px", color: "#344E41" }}>Feladatlap</p>
            </div>
            <div 
              onClick={() => setShowLinks(true)}
              style={{
              flex: 1,
              minWidth: "45%",
              backgroundColor: "#A3B18A",
              padding: "10px",
              borderRadius: "8px",
              textAlign: "center",
              cursor: "pointer"
            }}>
              <div style={{ fontSize: "20px", marginBottom: "5px" }}>🔗</div>
              <p style={{ margin: 0, fontSize: "11px", color: "#344E41" }}>Hivatkozás</p>
            </div>
          </div>
          
          {showLinks && (
            <div 
              style={{
                position: "fixed",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: "rgba(0,0,0,0.5)",
                zIndex: 1000,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: "20px"
              }}
              onClick={() => setShowLinks(false)}
            >
              <div 
                onClick={(e) => e.stopPropagation()}
                style={{ 
                  backgroundColor: "white", 
                  borderRadius: "15px", 
                  padding: "20px",
                  maxWidth: "500px",
                  width: "100%",
                  maxHeight: "80vh",
                  overflowY: "auto"
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "20px" }}>
                  <h3 style={{ margin: 0, color: "#344E41", fontSize: "18px" }}>📚 Hasznos hivatkozások</h3>
                  <button 
                    onClick={() => setShowLinks(false)}
                    style={{
                      background: "none",
                      border: "none",
                      fontSize: "24px",
                      cursor: "pointer",
                      color: "#888"
                    }}
                  >
                    ×
                  </button>
                </div>
                
                <div style={{ marginBottom: "20px" }}>
                  <p style={{ margin: "0 0 8px 0", fontSize: "14px", color: "#344E41", fontWeight: "500" }}>
                    Kriska György: Édesvízi gerinctelen állatok
                  </p>
                  <a 
                    href="https://library.hungaricana.hu/hu/view/VizugyiKonyvek_129/?pg=0&layout=s"
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ 
                      color: "#588157", 
                      fontSize: "13px",
                      textDecoration: "underline",
                      wordBreak: "break-all"
                    }}
                  >
                    library.hungaricana.hu/hu/view/VizugyiKonyvek_129
                  </a>
                </div>
                
                <div>
                  <p style={{ margin: "0 0 8px 0", fontSize: "14px", color: "#344E41", fontWeight: "500" }}>
                    Tudj meg többet a BISEL- A biológiai vízminősítés. Tudj meg róla többet:
                  </p>
                  <a 
                    href="https://bisel.hu/a-bisel-rol-roviden"
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ 
                      color: "#588157", 
                      fontSize: "13px",
                      textDecoration: "underline"
                    }}
                  >
                    bisel.hu/a-bisel-rol-roviden
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}