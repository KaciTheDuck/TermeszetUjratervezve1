import React, { useState } from 'react';

// settings page for the app

export default function Settings() {
  
  // toggle switches - on or off
  let [notifications, setNotifications] = useState(true);
  let [location, setLocation] = useState(true);
  let [darkMode, setDarkMode] = useState(false);

  return (
    <div style={{ backgroundColor: "#DAD7CD", minHeight: "100vh", paddingBottom: "100px" }}>
      
      {/* header */}
      <div style={{ backgroundColor: "#588157", padding: "40px 20px 50px 20px" }}>
        <h1 style={{ color: "white", fontSize: "24px", margin: 0 }}>Beállítások</h1>
        <p style={{ color: "rgba(255,255,255,0.6)", marginTop: "5px" }}>Szabd testre az alkalmazást</p>
      </div>

      {/* profile card */}
      <div style={{ padding: "0 20px", marginTop: "-30px" }}>
        <div style={{
          backgroundColor: "white",
          borderRadius: "15px",
          padding: "20px",
          display: "flex",
          alignItems: "center",
          gap: "15px",
          boxShadow: "0 2px 10px rgba(0,0,0,0.1)"
        }}>
          {/* profile picture placeholder */}
          <div style={{
            width: "60px",
            height: "60px",
            borderRadius: "50%",
            backgroundColor: "#3A5A40",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "white",
            fontSize: "24px"
          }}>
            H
          </div>
          <div>
            <p style={{ margin: 0, fontWeight: "bold" }}>Túrázó</p>
            <p style={{ margin: "5px 0 0 0", color: "#888", fontSize: "14px" }}>A kaland vár</p>
          </div>
        </div>
      </div>

      {/* settings options */}
      <div style={{ padding: "20px" }}>
        
        {/* preferences section */}
        <p style={{ color: "#888", fontSize: "12px", marginBottom: "10px" }}>PREFERENCIÁK</p>
        <div style={{ backgroundColor: "white", borderRadius: "15px", overflow: "hidden" }}>
          
          {/* notifications toggle */}
          <div style={{ padding: "15px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #f0f0f0" }}>
            <span>🔔 Értesítések</span>
            <button 
              onClick={function() { setNotifications(!notifications); }}
              style={{
                width: "50px",
                height: "28px",
                borderRadius: "14px",
                border: "none",
                backgroundColor: notifications ? "#1B4332" : "#ccc",
                cursor: "pointer",
                position: "relative"
              }}
            >
              <div style={{
                width: "22px",
                height: "22px",
                borderRadius: "50%",
                backgroundColor: "white",
                position: "absolute",
                top: "3px",
                left: notifications ? "25px" : "3px",
                transition: "left 0.2s"
              }}></div>
            </button>
          </div>
          
          {/* location toggle */}
          <div style={{ padding: "15px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #f0f0f0" }}>
            <span>📍 Helyzet</span>
            <button 
              onClick={function() { setLocation(!location); }}
              style={{
                width: "50px",
                height: "28px",
                borderRadius: "14px",
                border: "none",
                backgroundColor: location ? "#1B4332" : "#ccc",
                cursor: "pointer",
                position: "relative"
              }}
            >
              <div style={{
                width: "22px",
                height: "22px",
                borderRadius: "50%",
                backgroundColor: "white",
                position: "absolute",
                top: "3px",
                left: location ? "25px" : "3px",
                transition: "left 0.2s"
              }}></div>
            </button>
          </div>
          
          {/* dark mode toggle */}
          <div style={{ padding: "15px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span>🌙 Sötét mód</span>
            <button 
              onClick={function() { setDarkMode(!darkMode); }}
              style={{
                width: "50px",
                height: "28px",
                borderRadius: "14px",
                border: "none",
                backgroundColor: darkMode ? "#1B4332" : "#ccc",
                cursor: "pointer",
                position: "relative"
              }}
            >
              <div style={{
                width: "22px",
                height: "22px",
                borderRadius: "50%",
                backgroundColor: "white",
                position: "absolute",
                top: "3px",
                left: darkMode ? "25px" : "3px",
                transition: "left 0.2s"
              }}></div>
            </button>
          </div>
        </div>

        {/* account section */}
        <p style={{ color: "#888", fontSize: "12px", marginTop: "20px", marginBottom: "10px" }}>FIÓK</p>
        <div style={{ backgroundColor: "white", borderRadius: "15px", overflow: "hidden" }}>
          <div style={{ padding: "15px", borderBottom: "1px solid #f0f0f0" }}>
            <span>👤 Profil szerkesztése</span>
          </div>
          <div style={{ padding: "15px" }}>
            <span>🔒 Adatvédelem</span>
          </div>
        </div>

        {/* logout button */}
        <div style={{ backgroundColor: "white", borderRadius: "15px", marginTop: "20px" }}>
          <button style={{
            width: "100%",
            padding: "15px",
            border: "none",
            backgroundColor: "transparent",
            color: "red",
            cursor: "pointer",
            textAlign: "left"
          }}>
            🚪 Kijelentkezés
          </button>
        </div>

        {/* app version */}
        <p style={{ textAlign: "center", color: "#ccc", marginTop: "30px", fontSize: "12px" }}>
          Túraapp v1.0.0
        </p>
      </div>
    </div>
  );
}