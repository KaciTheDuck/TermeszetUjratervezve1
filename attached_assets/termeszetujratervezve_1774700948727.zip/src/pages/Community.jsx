import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Heart, MessageCircle, Share2, Send, Users, Plus, X } from 'lucide-react';

export default function Community() {
  const [postText, setPostText] = useState("");
  const [activeModal, setActiveModal] = useState(null);
  const [sharePostId, setSharePostId] = useState(null);
  const [friendEmail, setFriendEmail] = useState("");
  const queryClient = useQueryClient();

  // fetch data
  const { data: posts = [] } = useQuery({
    queryKey: ['posts'],
    queryFn: () => base44.entities.Post.list('-created_date', 50)
  });

  const { data: user } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const { data: connections = [] } = useQuery({
    queryKey: ['connections'],
    queryFn: async () => {
      const me = await base44.auth.me();
      return base44.entities.Connection.filter({ user_email: me.email });
    }
  });

  const { data: routes = [] } = useQuery({
    queryKey: ['routes'],
    queryFn: () => base44.entities.Route.list('-created_date', 20)
  });

  const { data: events = [] } = useQuery({
    queryKey: ['events'],
    queryFn: () => base44.entities.Event.list('date', 20)
  });

  // mutations
  const createPostMutation = useMutation({
    mutationFn: (postData) => base44.entities.Post.create(postData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
      setPostText("");
    }
  });

  const likePostMutation = useMutation({
    mutationFn: (post) => base44.entities.Post.update(post.id, { likes: post.likes + 1 }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
    }
  });

  const addFriendMutation = useMutation({
    mutationFn: async (email) => {
      const me = await base44.auth.me();
      return base44.entities.Connection.create({
        user_email: me.email,
        friend_email: email,
        friend_name: email.split('@')[0],
        status: "pending"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['connections'] });
      setFriendEmail("");
    }
  });

  const createRouteMutation = useMutation({
    mutationFn: (routeData) => base44.entities.Route.create(routeData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['routes'] });
      setActiveModal(null);
    }
  });

  const joinEventMutation = useMutation({
    mutationFn: (event) => base44.entities.Event.update(event.id, { 
      current_participants: event.current_participants + 1 
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['events'] });
    }
  });

  const handleCreatePost = () => {
    if (!postText.trim()) return;
    createPostMutation.mutate({
      content: postText,
      author_name: user?.full_name || 'Névtelen',
      likes: 0
    });
  };

  const handleShare = (postId) => {
    if (navigator.share) {
      navigator.share({
        title: 'Túra poszt',
        text: 'Nézd meg ezt a posztot!',
        url: window.location.href
      });
    } else {
      setSharePostId(postId);
      setTimeout(() => setSharePostId(null), 2000);
    }
  };

  return (
    <div style={{ backgroundColor: "#DAD7CD", minHeight: "100vh", paddingBottom: "100px" }}>
      
      {/* header */}
      <div style={{ 
        position: "relative",
        overflow: "hidden",
        padding: "40px 20px 30px 20px",
        boxShadow: "0 4px 20px rgba(0,0,0,0.1)"
      }}>
        <img 
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/695e6d1e5834f89bd833d7d2/d70f15aad_helena-lopes-PGnqT0rXWLs-unsplash.jpg"
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            objectFit: "cover",
            objectPosition: "center",
            zIndex: 0
          }}
          alt="Háttér"
        />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px", position: "relative", zIndex: 1 }}>
          <h1 style={{ color: "white", fontSize: "28px", margin: 0, fontWeight: "bold", textShadow: "0 2px 10px rgba(0,0,0,0.3)" }}>Közösség</h1>
          <button
            onClick={() => setActiveModal('friends')}
            style={{
              background: "rgba(255,255,255,0.2)",
              border: "none",
              color: "white",
              padding: "10px",
              borderRadius: "12px",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: "6px"
            }}>
            <Users size={20} />
            <span style={{ fontSize: "12px", fontWeight: "bold" }}>{connections.length}</span>
          </button>
        </div>
        <p style={{ color: "rgba(255,255,255,0.95)", margin: 0, fontSize: "14px", textShadow: "0 2px 8px rgba(0,0,0,0.3)", position: "relative", zIndex: 1 }}>Oszd meg élményeid és csatlakozz túrázókhoz</p>
      </div>

      {/* action cards */}
      <div style={{ padding: "20px", display: "flex", gap: "12px" }}>
        <div 
          onClick={() => setActiveModal('route')}
          style={{
            flex: 1,
            background: "linear-gradient(135deg, white 0%, #f8f9fa 100%)",
            borderRadius: "16px",
            padding: "20px",
            textAlign: "center",
            cursor: "pointer",
            boxShadow: "0 4px 12px rgba(0,0,0,0.08)"
          }}>
          <div style={{ fontSize: "32px", marginBottom: "10px" }}>🗺️</div>
          <p style={{ margin: 0, fontSize: "13px", fontWeight: "bold", color: "#344E41" }}>Új útvonal</p>
        </div>
        
        <div 
          onClick={() => setActiveModal('events')}
          style={{
            flex: 1,
            background: "linear-gradient(135deg, white 0%, #f8f9fa 100%)",
            borderRadius: "16px",
            padding: "20px",
            textAlign: "center",
            cursor: "pointer",
            boxShadow: "0 4px 12px rgba(0,0,0,0.08)"
          }}>
          <div style={{ fontSize: "32px", marginBottom: "10px" }}>📅</div>
          <p style={{ margin: 0, fontSize: "13px", fontWeight: "bold", color: "#344E41" }}>Események</p>
        </div>

        <div 
          onClick={() => setActiveModal('routes')}
          style={{
            flex: 1,
            background: "linear-gradient(135deg, white 0%, #f8f9fa 100%)",
            borderRadius: "16px",
            padding: "20px",
            textAlign: "center",
            cursor: "pointer",
            boxShadow: "0 4px 12px rgba(0,0,0,0.08)"
          }}>
          <div style={{ fontSize: "32px", marginBottom: "10px" }}>🧭</div>
          <p style={{ margin: 0, fontSize: "13px", fontWeight: "bold", color: "#344E41" }}>Útvonalak</p>
        </div>
      </div>

      {/* modals */}
        {activeModal && (
          <div 
            style={{
              position: "fixed",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              backgroundColor: "rgba(0,0,0,0.6)",
              zIndex: 1000,
              display: "flex",
              alignItems: "flex-end"
            }} 
            onClick={() => setActiveModal(null)}>
            <div 
              onClick={(e) => e.stopPropagation()}
              style={{
                backgroundColor: "#DAD7CD",
                width: "100%",
                maxHeight: "85vh",
                borderRadius: "24px 24px 0 0",
                display: "flex",
                flexDirection: "column",
                boxShadow: "0 -4px 30px rgba(0,0,0,0.2)"
              }}>
              {/* header */}
              <div style={{
                background: "linear-gradient(135deg, #344E41 0%, #588157 100%)",
                padding: "20px",
                borderRadius: "24px 24px 0 0",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between"
              }}>
                <h2 style={{ margin: 0, color: "white", fontSize: "18px", fontWeight: "bold" }}>
                  {activeModal === 'friends' && 'Barátok'}
                  {activeModal === 'route' && 'Új útvonal létrehozása'}
                  {activeModal === 'events' && 'Túra események'}
                  {activeModal === 'routes' && 'Közösségi útvonalak'}
                </h2>
                <button 
                  onClick={() => setActiveModal(null)}
                  style={{
                    background: "rgba(255,255,255,0.2)",
                    border: "none",
                    color: "white",
                    cursor: "pointer",
                    width: "32px",
                    height: "32px",
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center"
                  }}>
                  <X size={20} />
                </button>
              </div>
              
              {/* content */}
              <div style={{ flex: 1, overflowY: "auto", padding: "20px" }}>
                {activeModal === 'friends' && (
                  <>
                    <div style={{ marginBottom: "20px" }}>
                      <div style={{ display: "flex", gap: "10px" }}>
                        <input
                          type="email"
                          placeholder="Barát email címe..."
                          value={friendEmail}
                          onChange={(e) => setFriendEmail(e.target.value)}
                          style={{
                            flex: 1,
                            padding: "12px",
                            borderRadius: "12px",
                            border: "1px solid #ddd",
                            fontSize: "14px"
                          }}
                        />
                        <button
                          onClick={() => addFriendMutation.mutate(friendEmail)}
                          disabled={!friendEmail.includes('@')}
                          style={{
                            background: "linear-gradient(135deg, #588157 0%, #3A5A40 100%)",
                            color: "white",
                            border: "none",
                            padding: "12px 20px",
                            borderRadius: "12px",
                            cursor: "pointer",
                            display: "flex",
                            alignItems: "center",
                            gap: "6px"
                          }}>
                          <Plus size={18} />
                        </button>
                      </div>
                    </div>
                    {connections.map((conn) => (
                      <div key={conn.id} style={{
                        backgroundColor: "white",
                        padding: "15px",
                        borderRadius: "12px",
                        marginBottom: "10px",
                        display: "flex",
                        alignItems: "center",
                        gap: "12px"
                      }}>
                        <div style={{
                          width: "40px",
                          height: "40px",
                          borderRadius: "50%",
                          background: "linear-gradient(135deg, #588157 0%, #3A5A40 100%)",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          color: "white",
                          fontWeight: "bold"
                        }}>
                          {conn.friend_name[0]}
                        </div>
                        <div style={{ flex: 1 }}>
                          <p style={{ margin: 0, fontWeight: "bold", fontSize: "14px" }}>{conn.friend_name}</p>
                          <p style={{ margin: 0, fontSize: "12px", color: "#888" }}>{conn.friend_email}</p>
                        </div>
                        <span style={{
                          padding: "4px 12px",
                          borderRadius: "8px",
                          fontSize: "11px",
                          backgroundColor: conn.status === 'accepted' ? '#d4edda' : '#fff3cd',
                          color: conn.status === 'accepted' ? '#155724' : '#856404'
                        }}>
                          {conn.status === 'accepted' ? '✓ Elfogadva' : '⏳ Függőben'}
                        </span>
                      </div>
                    ))}
                  </>
                )}

                {activeModal === 'events' && (
                  <>
                    {events.length === 0 ? (
                      <p style={{ textAlign: "center", color: "#888", padding: "40px" }}>Még nincsenek események</p>
                    ) : (
                      events.map((event) => (
                        <div key={event.id} style={{
                          backgroundColor: "white",
                          padding: "18px",
                          borderRadius: "14px",
                          marginBottom: "12px",
                          boxShadow: "0 2px 8px rgba(0,0,0,0.08)"
                        }}>
                          <h3 style={{ margin: "0 0 8px 0", fontSize: "16px", color: "#344E41" }}>{event.title}</h3>
                          <p style={{ margin: "0 0 12px 0", fontSize: "13px", color: "#666" }}>{event.description}</p>
                          <div style={{ display: "flex", gap: "15px", fontSize: "12px", color: "#888", marginBottom: "12px" }}>
                            <span>📅 {new Date(event.date).toLocaleDateString('hu-HU')}</span>
                            <span>📍 {event.location}</span>
                            <span>👥 {event.current_participants}/{event.max_participants}</span>
                          </div>
                          <button
                            onClick={() => joinEventMutation.mutate(event)}
                            disabled={event.current_participants >= event.max_participants}
                            style={{
                              background: event.current_participants >= event.max_participants ? "#ccc" : "linear-gradient(135deg, #588157 0%, #3A5A40 100%)",
                              color: "white",
                              border: "none",
                              padding: "10px 20px",
                              borderRadius: "10px",
                              cursor: event.current_participants >= event.max_participants ? "not-allowed" : "pointer",
                              fontSize: "13px",
                              fontWeight: "bold",
                              width: "100%"
                            }}>
                            {event.current_participants >= event.max_participants ? 'Betelt' : 'Csatlakozom'}
                          </button>
                        </div>
                      ))
                    )}
                  </>
                )}

                {activeModal === 'routes' && (
                  <>
                    {routes.length === 0 ? (
                      <p style={{ textAlign: "center", color: "#888", padding: "40px" }}>Még nincsenek útvonalak</p>
                    ) : (
                      routes.map((route) => (
                        <div key={route.id} style={{
                          backgroundColor: "white",
                          padding: "18px",
                          borderRadius: "14px",
                          marginBottom: "12px",
                          boxShadow: "0 2px 8px rgba(0,0,0,0.08)"
                        }}>
                          <h3 style={{ margin: "0 0 8px 0", fontSize: "16px", color: "#344E41" }}>{route.name}</h3>
                          <p style={{ margin: "0 0 12px 0", fontSize: "13px", color: "#666" }}>{route.description}</p>
                          <div style={{ display: "flex", gap: "12px", fontSize: "12px", color: "#888", flexWrap: "wrap" }}>
                            {route.distance && <span>📏 {route.distance} km</span>}
                            {route.difficulty && <span>⚡ {route.difficulty}</span>}
                            {route.location && <span>📍 {route.location}</span>}
                            <span>👤 {route.creator_name}</span>
                          </div>
                        </div>
                      ))
                    )}
                  </>
                )}

                {activeModal === 'route' && (
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    const formData = new FormData(e.target);
                    createRouteMutation.mutate({
                      name: formData.get('name'),
                      description: formData.get('description'),
                      distance: Number(formData.get('distance')),
                      difficulty: formData.get('difficulty'),
                      location: formData.get('location'),
                      creator_name: user?.full_name || 'Névtelen'
                    });
                  }}>
                    <input name="name" placeholder="Útvonal neve" required style={{
                      width: "100%",
                      padding: "12px",
                      borderRadius: "12px",
                      border: "1px solid #ddd",
                      marginBottom: "12px",
                      fontSize: "14px"
                    }} />
                    <textarea name="description" placeholder="Leírás" rows="3" style={{
                      width: "100%",
                      padding: "12px",
                      borderRadius: "12px",
                      border: "1px solid #ddd",
                      marginBottom: "12px",
                      fontSize: "14px",
                      fontFamily: "inherit",
                      resize: "vertical"
                    }} />
                    <input name="distance" type="number" placeholder="Távolság (km)" step="0.1" style={{
                      width: "100%",
                      padding: "12px",
                      borderRadius: "12px",
                      border: "1px solid #ddd",
                      marginBottom: "12px",
                      fontSize: "14px"
                    }} />
                    <select name="difficulty" style={{
                      width: "100%",
                      padding: "12px",
                      borderRadius: "12px",
                      border: "1px solid #ddd",
                      marginBottom: "12px",
                      fontSize: "14px"
                    }}>
                      <option value="könnyű">Könnyű</option>
                      <option value="közepes">Közepes</option>
                      <option value="nehéz">Nehéz</option>
                    </select>
                    <input name="location" placeholder="Helyszín" style={{
                      width: "100%",
                      padding: "12px",
                      borderRadius: "12px",
                      border: "1px solid #ddd",
                      marginBottom: "20px",
                      fontSize: "14px"
                    }} />
                    <button
                      type="submit"
                      style={{
                        background: "linear-gradient(135deg, #588157 0%, #3A5A40 100%)",
                        color: "white",
                        border: "none",
                        padding: "14px",
                        borderRadius: "12px",
                        cursor: "pointer",
                        fontSize: "15px",
                        fontWeight: "bold",
                        width: "100%"
                      }}>
                      Útvonal létrehozása
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        )}

      {/* create post */}
      <div style={{ padding: "0 20px 20px 20px" }}>
        <div 
          style={{ 
            backgroundColor: "white", 
            borderRadius: "20px", 
            padding: "20px", 
            boxShadow: "0 4px 15px rgba(0,0,0,0.1)" 
          }}>
          <div style={{ display: "flex", gap: "12px", marginBottom: "12px" }}>
            <div style={{
              width: "44px",
              height: "44px", 
              borderRadius: "50%",
              background: "linear-gradient(135deg, #588157 0%, #3A5A40 100%)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "white",
              fontWeight: "bold",
              fontSize: "18px",
              flexShrink: 0
            }}>
              {user?.full_name?.[0] || 'T'}
            </div>
            
            <textarea
              placeholder="Oszd meg élményeid..."
              value={postText}
              onChange={(e) => setPostText(e.target.value)}
              style={{
                flex: 1,
                border: "none",
                backgroundColor: "#f8f9fa",
                borderRadius: "14px",
                padding: "12px 16px",
                resize: "none",
                height: "80px",
                fontSize: "14px",
                fontFamily: "inherit"
              }}
            />
          </div>
          
          <div style={{ display: "flex", justifyContent: "flex-end" }}>
            <button 
              onClick={handleCreatePost}
              disabled={!postText.trim()}
              style={{
                background: postText.trim() ? "linear-gradient(135deg, #588157 0%, #3A5A40 100%)" : "#ccc",
                color: "white",
                border: "none",
                padding: "10px 24px",
                borderRadius: "12px",
                cursor: postText.trim() ? "pointer" : "not-allowed",
                fontWeight: "bold",
                fontSize: "14px",
                display: "flex",
                alignItems: "center",
                gap: "8px"
              }}>
              <Send size={16} />
              Közzététel
            </button>
          </div>
        </div>
      </div>

      {/* posts feed */}
      <div style={{ padding: "0 20px" }}>
          {posts.map((post) => (
            <div 
              key={post.id}
              style={{
                backgroundColor: "white",
                borderRadius: "20px",
                marginBottom: "16px",
                overflow: "hidden",
                boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
                position: "relative"
              }}>
              {sharePostId === post.id && (
                <div style={{
                  position: "absolute",
                  top: "50%",
                  left: "50%",
                  transform: "translate(-50%, -50%)",
                  backgroundColor: "rgba(0,0,0,0.8)",
                  color: "white",
                  padding: "10px 20px",
                  borderRadius: "10px",
                  zIndex: 10
                }}>
                  Link másolva!
                </div>
              )}
              
              <div style={{ padding: "18px", display: "flex", alignItems: "center", gap: "12px" }}>
                <div style={{
                  width: "44px",
                  height: "44px",
                  borderRadius: "50%",
                  background: "linear-gradient(135deg, #588157 0%, #3A5A40 100%)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "white",
                  fontWeight: "bold"
                }}>
                  {post.author_name[0]}
                </div>
                <div>
                  <p style={{ margin: 0, fontWeight: "bold", fontSize: "15px", color: "#344E41" }}>
                    {post.author_name}
                  </p>
                  <p style={{ margin: 0, color: "#888", fontSize: "12px" }}>
                    {new Date(post.created_date).toLocaleDateString('hu-HU')}
                  </p>
                </div>
              </div>
              
              <p style={{ padding: "0 18px 18px 18px", margin: 0, lineHeight: "1.5", color: "#344E41" }}>
                {post.content}
              </p>
              
              {post.image_url && (
                <img src={post.image_url} alt="post" style={{ width: "100%", height: "240px", objectFit: "cover" }} />
              )}
              
              <div style={{ padding: "12px 18px", borderTop: "1px solid #f0f0f0", display: "flex", gap: "20px" }}>
                <button 
                  onClick={() => likePostMutation.mutate(post)}
                  style={{ 
                    background: "none", 
                    border: "none", 
                    color: post.likes > 0 ? "#e74c3c" : "#888", 
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    gap: "6px",
                    fontSize: "14px",
                    fontWeight: "500"
                  }}>
                  <Heart size={18} fill={post.likes > 0 ? "#e74c3c" : "none"} />
                  {post.likes}
                </button>
                
                <button style={{ 
                  background: "none", 
                  border: "none", 
                  color: "#888", 
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  fontSize: "14px"
                }}>
                  <MessageCircle size={18} />
                </button>
                
                <button 
                  onClick={() => handleShare(post.id)}
                  style={{ 
                    background: "none", 
                    border: "none", 
                    color: "#888", 
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                    gap: "6px",
                    fontSize: "14px"
                  }}>
                  <Share2 size={18} />
                </button>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
}