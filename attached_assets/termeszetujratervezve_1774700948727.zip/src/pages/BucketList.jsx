import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

function createPageUrl(pageName) {
  return `/${pageName}`;
}

export default function BucketList() {
  const navigate = useNavigate();
  
  const bucketListItems = [
    "Állj meg 1 percre, amikor a legfáradtabbnak érzed magad",
    "Figyelj egy élőlényt 1 teljes percig",
    "Fotózz le valamit, amit addig nem vettél észre és kezd el tanulmányozni",
    "Köszönd meg egy fának, hogy árnyékot ad",
    "Ölelj meg egy fát",
    "Csukd be a szemed 30 mp-re – hány különböző hangot hallasz?",
    "Találj egy helyet, aminek erdőszaga van",
    "Érints meg 3 különböző felszínű dolgot (kéreg, kő, levél)",
    "Keresd meg a legnagyobb fát amit eddig láttál",
    "A túra végén válassz ki egy kedvenc fát/követ, fotózd le vagy nevezd el"
  ];
  
  return (
    <div style={{ backgroundColor: "#DAD7CD", minHeight: "100vh", paddingBottom: "100px" }}>
      
      {/* header */}
      <div style={{ 
        backgroundImage: "url('https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=1920&q=80')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        padding: "40px 20px 30px 20px",
        position: "relative"
      }}>
        <button
          onClick={() => navigate(createPageUrl('NatureExplorer'))}
          style={{
            background: "rgba(255,255,255,0.2)",
            border: "none",
            color: "white",
            padding: "8px",
            borderRadius: "50%",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            marginBottom: "15px"
          }}
        >
          <ArrowLeft size={20} />
        </button>
        <h1 style={{ color: "white", fontSize: "24px", margin: 0, textShadow: "0 2px 10px rgba(0,0,0,0.3)" }}>
          🎒 Bakancslista
        </h1>
        <p style={{ color: "rgba(255,255,255,0.9)", marginTop: "5px", textShadow: "0 2px 8px rgba(0,0,0,0.3)" }}>
          Próbálj ki minél többet ezek közül a természeti élmények közül a következő túrád során!
        </p>
      </div>

      {/* content */}
      <div style={{ padding: "20px" }}>
        <div style={{
          backgroundColor: "#f8f9fa",
          borderRadius: "15px",
          padding: "20px",
          marginBottom: "20px"
        }}>
          <p style={{ margin: 0, fontSize: "14px", color: "#666", lineHeight: "1.6" }}>
            📝 Próbálj ki minél többet ezek közül a természeti élmények közül a következő túrád során!
          </p>
        </div>

        <div style={{
          backgroundColor: "white",
          borderRadius: "15px",
          padding: "15px",
          boxShadow: "0 2px 10px rgba(0,0,0,0.1)"
        }}>
          <img
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/695e6d1e5834f89bd833d7d2/af69e04d5_BAKANCSLISTA_page-0001.jpg"
            alt="Bakancslista"
            style={{
              width: "100%",
              height: "auto",
              borderRadius: "10px"
            }}
          />
        </div>
      </div>
    </div>
  );
}