import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Polyline, Marker, Popup } from 'react-leaflet';
import { ArrowLeft, Search, X, ChevronUp } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

function createPageUrl(pageName) {
  return `/${pageName}`;
}

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

export default function Map() {
  const [allRoutes, setAllRoutes] = useState([]);
  const [routeData, setRouteData] = useState(null);
  const [showPanel, setShowPanel] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [showSearch, setShowSearch] = useState(false);

  useEffect(() => {
    async function loadAllRoutes() {
      try {
        const trails = await base44.entities.TrailRoute.list('-created_date', 100);
        const routes = await base44.entities.Route.list('-created_date', 100);
        setAllRoutes([...(trails || []), ...(routes || [])]);
      } catch (error) {
        console.error('Error loading routes:', error);
      }
    }
    loadAllRoutes();
  }, []);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const routeId = urlParams.get('routeId');
    const trailRouteId = urlParams.get('trailRouteId');

    async function loadRoute() {
      try {
        if (routeId) {
          const routes = await base44.entities.Route.list();
          const route = routes.find(r => r.id === routeId);
          if (route) {
            setRouteData(route);
            setShowPanel(true);
          }
        } else if (trailRouteId) {
          const trails = await base44.entities.TrailRoute.list();
          const trail = trails.find(t => t.id === trailRouteId);
          if (trail) {
            setRouteData(trail);
            setShowPanel(true);
          }
        }
      } catch (error) {
        console.error('Error loading route:', error);
      }
    }

    if (routeId || trailRouteId) {
      loadRoute();
    }
  }, []);

  const handleSearch = (query) => {
    setSearchQuery(query);
    if (query.trim().length > 0) {
      const results = allRoutes.filter(route => 
        route.name?.toLowerCase().includes(query.toLowerCase()) ||
        route.location?.toLowerCase().includes(query.toLowerCase())
      );
      setSearchResults(results);
      setShowSearch(true);
    } else {
      setSearchResults([]);
      setShowSearch(false);
    }
  };

  const selectRoute = (route) => {
    setRouteData(route);
    setShowSearch(false);
    setSearchQuery('');
    setShowPanel(true);
  };

  const mapCenter = routeData?.start_lat && routeData?.start_lon 
    ? [routeData.start_lat, routeData.start_lon] 
    : [45.9432, 24.9668];
  const mapZoom = routeData ? 12 : 7;

  return (
    <div style={{ 
      position: "relative", 
      height: "100vh", 
      width: "100%", 
      overflow: "hidden",
      backgroundColor: "#DAD7CD"
    }}>
      
      <div style={{ 
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 1
      }}>
        <MapContainer
          center={mapCenter}
          zoom={mapZoom}
          style={{ height: "100vh", width: "100%" }}
          key={routeData ? routeData.id : 'default'}
          zoomControl={false}
        >
          <TileLayer
            url="https://tile.opentopomap.org/{z}/{x}/{y}.png"
            attribution='&copy; OpenTopoMap'
            maxZoom={17}
          />
          <TileLayer
            url="https://tile.waymarkedtrails.org/hiking/{z}/{x}/{y}.png"
            attribution='&copy; Waymarked Trails'
            opacity={0.7}
          />
          
          {routeData?.start_lat && routeData?.start_lon && (
            <>
              <Marker position={[routeData.start_lat, routeData.start_lon]}>
                <Popup>Kezdőpont: {routeData.name}</Popup>
              </Marker>
              {routeData.end_lat && routeData.end_lon && (
                <>
                  <Marker position={[routeData.end_lat, routeData.end_lon]}>
                    <Popup>Végpont</Popup>
                  </Marker>
                  <Polyline
                    positions={[
                      [routeData.start_lat, routeData.start_lon],
                      [routeData.end_lat, routeData.end_lon]
                    ]}
                    color="#588157"
                    weight={4}
                  />
                </>
              )}
            </>
          )}
          
          {allRoutes.map((route) => (
            route.start_lat && route.start_lon && route.id !== routeData?.id && (
              <Marker 
                key={route.id} 
                position={[route.start_lat, route.start_lon]}
                eventHandlers={{ click: () => selectRoute(route) }}
              >
                <Popup>
                  <strong>{route.name}</strong><br/>
                  {route.distance && <span>📏 {route.distance} km</span>}
                </Popup>
              </Marker>
            )
          ))}
        </MapContainer>
      </div>

      <div style={{
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 1002,
        padding: "15px",
        background: "linear-gradient(to bottom, rgba(0,0,0,0.3), transparent)"
      }}>
        <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
          {routeData && (
            <button
              onClick={() => {
                setRouteData(null);
                setShowPanel(false);
              }}
              style={{
                width: "40px",
                height: "40px",
                borderRadius: "50%",
                backgroundColor: "white",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                boxShadow: "0 2px 10px rgba(0,0,0,0.2)",
                border: "none",
                cursor: "pointer",
                color: "#344E41"
              }}
            >
              <ArrowLeft size={20} />
            </button>
          )}
          <div style={{
            flex: 1,
            backgroundColor: "white",
            borderRadius: "25px",
            padding: "10px 15px",
            display: "flex",
            alignItems: "center",
            gap: "10px",
            boxShadow: "0 2px 10px rgba(0,0,0,0.2)"
          }}>
            <Search size={18} color="#888" />
            <input 
              placeholder="Túraútvonalak keresése..."
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              onFocus={() => searchQuery && setShowSearch(true)}
              style={{
                flex: 1,
                border: "none",
                outline: "none",
                fontSize: "14px",
                backgroundColor: "transparent"
              }}
            />
            {searchQuery && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setShowSearch(false);
                  setSearchResults([]);
                }}
                style={{
                  background: "none",
                  border: "none",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  padding: "0"
                }}
              >
                <X size={18} color="#888" />
              </button>
            )}
          </div>
        </div>
      </div>

      {showSearch && (
        <div style={{
          position: "absolute",
          top: "80px",
          left: "15px",
          right: "15px",
          zIndex: 1002,
          backgroundColor: "white",
          borderRadius: "15px",
          maxHeight: "400px",
          overflowY: "auto",
          boxShadow: "0 4px 20px rgba(0,0,0,0.2)"
        }}>
          {searchResults.length > 0 ? (
            searchResults.map((route) => (
              <div
                key={route.id}
                onClick={() => selectRoute(route)}
                style={{
                  padding: "15px",
                  borderBottom: "1px solid #f0f0f0",
                  cursor: "pointer"
                }}
              >
                <p style={{ margin: 0, fontWeight: "bold", fontSize: "14px", color: "#344E41" }}>
                  {route.name}
                </p>
                <div style={{ display: "flex", gap: "10px", fontSize: "12px", color: "#888", marginTop: "4px" }}>
                  {route.distance && <span>📏 {route.distance} km</span>}
                  {route.location && <span>📍 {route.location}</span>}
                </div>
              </div>
            ))
          ) : (
            <div style={{ padding: "20px", textAlign: "center", color: "#888" }}>
              Nincs találat
            </div>
          )}
        </div>
      )}

      {routeData && (
        <div style={{
          position: "absolute",
          bottom: showPanel ? 0 : "-320px",
          left: 0,
          right: 0,
          zIndex: 1002,
          backgroundColor: "white",
          borderRadius: "25px 25px 0 0",
          padding: "20px",
          paddingBottom: "100px",
          boxShadow: "0 -4px 20px rgba(0,0,0,0.15)",
          transition: "bottom 0.3s ease"
        }}>
          <button
            onClick={() => setShowPanel(!showPanel)}
            style={{
              position: "absolute",
              top: "10px",
              left: "50%",
              transform: "translateX(-50%)",
              background: "none",
              border: "none",
              cursor: "pointer"
            }}
          >
            <ChevronUp size={24} color="#888" style={{ 
              transform: showPanel ? "rotate(180deg)" : "rotate(0deg)",
              transition: "transform 0.3s ease"
            }} />
          </button>

          <div style={{ marginTop: "20px" }}>
            <h2 style={{ margin: "0 0 10px 0", fontSize: "20px", color: "#344E41" }}>
              {routeData.name}
            </h2>
            <div style={{ display: "flex", gap: "15px", fontSize: "14px", color: "#888", marginBottom: "20px", flexWrap: "wrap" }}>
              {routeData.distance && <span>📏 {routeData.distance} km</span>}
              {routeData.duration && <span>⏱️ {routeData.duration}</span>}
              {routeData.elevation && <span>⛰️ {routeData.elevation}m</span>}
              {routeData.difficulty && <span>🎯 {routeData.difficulty}</span>}
            </div>

            {routeData.description && (
              <p style={{ fontSize: "14px", color: "#666", lineHeight: "1.6" }}>
                {routeData.description}
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}