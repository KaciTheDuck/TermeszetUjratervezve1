import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Edit2, MapPin, TrendingUp, Award, Camera, LogOut } from 'lucide-react';

export default function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({});
  const [uploading, setUploading] = useState(false);
  const queryClient = useQueryClient();

  const { data: user, isLoading } = useQuery({
    queryKey: ['currentUser'],
    queryFn: () => base44.auth.me()
  });

  const { data: myPosts = [] } = useQuery({
    queryKey: ['myPosts'],
    queryFn: async () => {
      const me = await base44.auth.me();
      return base44.entities.Post.filter({ created_by: me.email });
    }
  });

  const { data: myRoutes = [] } = useQuery({
    queryKey: ['myRoutes'],
    queryFn: async () => {
      const me = await base44.auth.me();
      return base44.entities.Route.filter({ created_by: me.email });
    }
  });

  const updateProfileMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUser'] });
      setIsEditing(false);
    }
  });

  const handleEdit = () => {
    setEditData({
      bio: user?.bio || '',
      location: user?.location || '',
      level: user?.level || 'kezdő'
    });
    setIsEditing(true);
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      await updateProfileMutation.mutateAsync({ profile_image: file_url });
    } catch (error) {
      alert('Hiba történt a feltöltés során');
    } finally {
      setUploading(false);
    }
  };

  const handleSave = () => {
    const { full_name, ...dataToSave } = editData;
    updateProfileMutation.mutate(dataToSave);
  };

  const handleLogout = () => {
    base44.auth.logout();
  };

  if (isLoading) {
    return (
      <div style={{ backgroundColor: "#DAD7CD", minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ 
          width: "40px", 
          height: "40px", 
          border: "3px solid #f3f3f3",
          borderTop: "3px solid #588157",
          borderRadius: "50%",
          animation: "spin 1s linear infinite"
        }}></div>
      </div>
    );
  }

  return (
    <div style={{ backgroundColor: "#DAD7CD", minHeight: "100vh", paddingBottom: "100px" }}>
      
      {/* header with gradient */}
      <div style={{ 
        backgroundImage: "url('https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/695e6d1e5834f89bd833d7d2/2111efa43_holly-mandarich-UVyOfX3v0Ls-unsplash.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        padding: "40px 20px 80px 20px",
        position: "relative"
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h1 style={{ color: "white", fontSize: "24px", margin: 0, fontWeight: "bold", textShadow: "0 2px 10px rgba(0,0,0,0.3)" }}>Profilom</h1>
          <button
            onClick={handleLogout}
            style={{
              background: "rgba(255,255,255,0.2)",
              border: "none",
              color: "white",
              padding: "8px 16px",
              borderRadius: "10px",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: "6px",
              fontSize: "13px"
            }}>
            <LogOut size={16} />
            Kilépés
          </button>
        </div>
      </div>

      {/* profile card */}
      <div style={{ padding: "0 20px", marginTop: "-60px" }}>
        <div 
          style={{ 
            backgroundColor: "white", 
            borderRadius: "20px", 
            padding: "25px", 
            boxShadow: "0 8px 30px rgba(0,0,0,0.12)",
            position: "relative"
          }}>
          
          {/* profile image */}
          <div style={{ textAlign: "center", marginBottom: "20px" }}>
            <div style={{ position: "relative", display: "inline-block" }}>
              <div style={{
                width: "100px",
                height: "100px",
                borderRadius: "50%",
                background: user?.profile_image ? `url(${user.profile_image})` : "linear-gradient(135deg, #588157 0%, #3A5A40 100%)",
                backgroundSize: "cover",
                backgroundPosition: "center",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "white",
                fontSize: "36px",
                fontWeight: "bold",
                border: "4px solid white",
                boxShadow: "0 4px 12px rgba(0,0,0,0.15)"
              }}>
                {!user?.profile_image && (user?.full_name?.[0] || 'T')}
              </div>
              <label style={{
                position: "absolute",
                bottom: "0",
                right: "0",
                width: "32px",
                height: "32px",
                borderRadius: "50%",
                background: uploading ? "#ccc" : "linear-gradient(135deg, #588157 0%, #3A5A40 100%)",
                border: "2px solid white",
                color: "white",
                cursor: uploading ? "not-allowed" : "pointer",
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
              }}>
                <Camera size={16} />
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={handleImageUpload}
                  disabled={uploading}
                  style={{ display: "none" }}
                />
              </label>
            </div>
            <h2 style={{ margin: "15px 0 5px 0", fontSize: "22px", color: "#344E41" }}>{user?.full_name}</h2>
            <p style={{ margin: 0, color: "#888", fontSize: "14px" }}>{user?.email}</p>
          </div>

          {/* edit button */}
          {!isEditing && (
            <button
              onClick={handleEdit}
              style={{
                position: "absolute",
                top: "20px",
                right: "20px",
                background: "rgba(88,129,87,0.1)",
                border: "none",
                color: "#588157",
                padding: "8px 12px",
                borderRadius: "10px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: "6px",
                fontSize: "13px",
                fontWeight: "bold"
              }}>
              <Edit2 size={14} />
              Szerkesztés
            </button>
          )}

          {/* profile info */}
          {isEditing ? (
            <div style={{ marginTop: "20px" }}>

              <div style={{ marginBottom: "15px" }}>
                <label style={{ display: "block", fontSize: "12px", color: "#888", marginBottom: "5px" }}>Bemutatkozás</label>
                <textarea
                  value={editData.bio}
                  onChange={(e) => setEditData({...editData, bio: e.target.value})}
                  placeholder="Írj magadról..."
                  style={{
                    width: "100%",
                    padding: "12px",
                    borderRadius: "10px",
                    border: "1px solid #ddd",
                    fontSize: "14px",
                    fontFamily: "inherit",
                    resize: "vertical",
                    minHeight: "80px"
                  }}
                />
              </div>
              <div style={{ marginBottom: "15px" }}>
                <label style={{ display: "block", fontSize: "12px", color: "#888", marginBottom: "5px" }}>Helyszín</label>
                <input
                  value={editData.location}
                  onChange={(e) => setEditData({...editData, location: e.target.value})}
                  placeholder="Város, régió..."
                  style={{
                    width: "100%",
                    padding: "12px",
                    borderRadius: "10px",
                    border: "1px solid #ddd",
                    fontSize: "14px"
                  }}
                />
              </div>
              <div style={{ marginBottom: "20px" }}>
                <label style={{ display: "block", fontSize: "12px", color: "#888", marginBottom: "5px" }}>Túrázói szint</label>
                <select
                  value={editData.level}
                  onChange={(e) => setEditData({...editData, level: e.target.value})}
                  style={{
                    width: "100%",
                    padding: "12px",
                    borderRadius: "10px",
                    border: "1px solid #ddd",
                    fontSize: "14px"
                  }}>
                  <option value="kezdő">Kezdő</option>
                  <option value="haladó">Haladó</option>
                  <option value="profi">Profi</option>
                </select>
              </div>
              <div style={{ display: "flex", gap: "10px" }}>
                <button
                  onClick={() => setIsEditing(false)}
                  style={{
                    flex: 1,
                    padding: "12px",
                    borderRadius: "10px",
                    border: "1px solid #ddd",
                    background: "white",
                    cursor: "pointer",
                    fontSize: "14px",
                    fontWeight: "bold"
                  }}>
                  Mégse
                </button>
                <button
                  onClick={handleSave}
                  style={{
                    flex: 1,
                    padding: "12px",
                    borderRadius: "10px",
                    border: "none",
                    background: "linear-gradient(135deg, #588157 0%, #3A5A40 100%)",
                    color: "white",
                    cursor: "pointer",
                    fontSize: "14px",
                    fontWeight: "bold"
                  }}>
                  Mentés
                </button>
              </div>
            </div>
          ) : (
            <>
              {user?.bio && (
                <div style={{ marginBottom: "20px", padding: "15px", backgroundColor: "#f8f9fa", borderRadius: "12px" }}>
                  <p style={{ margin: 0, fontSize: "14px", lineHeight: "1.6", color: "#344E41" }}>{user.bio}</p>
                </div>
              )}
              
              <div style={{ display: "flex", gap: "15px", flexWrap: "wrap", marginBottom: "20px" }}>
                {user?.location && (
                  <div style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "14px", color: "#666" }}>
                    <MapPin size={16} />
                    {user.location}
                  </div>
                )}
                <div style={{ display: "flex", alignItems: "center", gap: "6px", fontSize: "14px", color: "#666" }}>
                  <TrendingUp size={16} />
                  {user?.level || 'kezdő'}
                </div>
              </div>

              {/* stats */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "10px", marginTop: "20px" }}>
                <div style={{ textAlign: "center", padding: "15px", backgroundColor: "#f8f9fa", borderRadius: "12px" }}>
                  <p style={{ margin: 0, fontSize: "24px", fontWeight: "bold", color: "#588157" }}>{user?.total_hikes || 0}</p>
                  <p style={{ margin: "5px 0 0 0", fontSize: "12px", color: "#888" }}>Túrák</p>
                </div>
                <div style={{ textAlign: "center", padding: "15px", backgroundColor: "#f8f9fa", borderRadius: "12px" }}>
                  <p style={{ margin: 0, fontSize: "24px", fontWeight: "bold", color: "#588157" }}>{user?.total_distance || 0}</p>
                  <p style={{ margin: "5px 0 0 0", fontSize: "12px", color: "#888" }}>km</p>
                </div>
                <div style={{ textAlign: "center", padding: "15px", backgroundColor: "#f8f9fa", borderRadius: "12px" }}>
                  <p style={{ margin: 0, fontSize: "24px", fontWeight: "bold", color: "#588157" }}>{myPosts.length}</p>
                  <p style={{ margin: "5px 0 0 0", fontSize: "12px", color: "#888" }}>Posztok</p>
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* achievements */}
      <div style={{ padding: "20px" }}>
        <h3 style={{ fontSize: "18px", marginBottom: "15px", color: "#344E41" }}>Eredmények</h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "12px" }}>
          <div style={{
            backgroundColor: "white",
            padding: "20px",
            borderRadius: "16px",
            textAlign: "center",
            boxShadow: "0 2px 8px rgba(0,0,0,0.08)"
          }}>
            <div style={{ fontSize: "36px", marginBottom: "8px" }}>🏆</div>
            <p style={{ margin: 0, fontSize: "13px", color: "#888" }}>Első túra</p>
          </div>
          <div style={{
            backgroundColor: "white",
            padding: "20px",
            borderRadius: "16px",
            textAlign: "center",
            boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
            opacity: 0.5
          }}>
            <div style={{ fontSize: "36px", marginBottom: "8px" }}>⭐</div>
            <p style={{ margin: 0, fontSize: "13px", color: "#888" }}>10 túra</p>
          </div>
          <div style={{
            backgroundColor: "white",
            padding: "20px",
            borderRadius: "16px",
            textAlign: "center",
            boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
            opacity: 0.5
          }}>
            <div style={{ fontSize: "36px", marginBottom: "8px" }}>🎖️</div>
            <p style={{ margin: 0, fontSize: "13px", color: "#888" }}>50 km</p>
          </div>
          <div style={{
            backgroundColor: "white",
            padding: "20px",
            borderRadius: "16px",
            textAlign: "center",
            boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
            opacity: 0.5
          }}>
            <div style={{ fontSize: "36px", marginBottom: "8px" }}>🔥</div>
            <p style={{ margin: 0, fontSize: "13px", color: "#888" }}>Heti sorozat</p>
          </div>
        </div>
      </div>

      {/* my routes */}
      {myRoutes.length > 0 && (
        <div style={{ padding: "0 20px 20px 20px" }}>
          <h3 style={{ fontSize: "18px", marginBottom: "15px", color: "#344E41" }}>Saját útvonalak</h3>
          {myRoutes.map((route) => (
            <div key={route.id} style={{
              backgroundColor: "white",
              padding: "15px",
              borderRadius: "14px",
              marginBottom: "10px",
              boxShadow: "0 2px 8px rgba(0,0,0,0.08)"
            }}>
              <h4 style={{ margin: "0 0 8px 0", fontSize: "15px", color: "#344E41" }}>{route.name}</h4>
              <div style={{ display: "flex", gap: "12px", fontSize: "12px", color: "#888" }}>
                {route.distance && <span>📏 {route.distance} km</span>}
                {route.difficulty && <span>⚡ {route.difficulty}</span>}
                {route.location && <span>📍 {route.location}</span>}
              </div>
            </div>
          ))}
        </div>
      )}

      <style>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}