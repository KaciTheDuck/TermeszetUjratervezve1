import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';

function createPageUrl(pageName) {
  return `/${pageName}`;
}

export default function Interactive() {
  const [routes, setRoutes] = useState([]);
  const [trailRoutes, setTrailRoutes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      try {
        const routesData = await base44.entities.Route.list('-created_date', 100);
        const trailRoutesData = await base44.entities.TrailRoute.list('-created_date', 100);
        
        const filtered = (routesData || []).filter(r => 
          r.name === 'Nagykőhavas' || r.name === 'Scropoasa tó'
        );
        
        setRoutes(filtered);
        setTrailRoutes(trailRoutesData || []);
      } catch (error) {
        console.error('Error loading data:', error);
      } finally {
        setLoading(false);
      }
    }
    
    loadData();
  }, []);

  return (
    <div style={{ backgroundColor: "#DAD7CD", minHeight: "100vh", paddingBottom: "100px" }}>
      <div style={{ 
        backgroundImage: "url('https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/695e6d1e5834f89bd833d7d2/72146dee5_adam-kool-ndN00KmbJ1c-unsplash.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        height: "200px",
        display: "flex",
        alignItems: "flex-end",
        padding: "20px"
      }}>
        <div>
          <h1 style={{ color: "white", fontSize: "28px", margin: 0, textShadow: "0 2px 4px rgba(0,0,0,0.5)" }}>
            Felfedezés
          </h1>
          <p style={{ color: "rgba(255,255,255,0.9)", margin: "5px 0 0 0", textShadow: "0 2px 4px rgba(0,0,0,0.5)" }}>
            Találd meg következő kalandod
          </p>
        </div>
      </div>

      <div style={{ padding: "20px" }}>
        {loading ? (
          <div style={{ textAlign: "center", padding: "40px", color: "#344E41" }}>
            Betöltés...
          </div>
        ) : (
          <>
            <h2 style={{ fontSize: "18px", marginBottom: "15px", color: "#344E41" }}>
              Saját túrák ({routes.length})
            </h2>

            {routes.length === 0 ? (
              <div style={{
                backgroundColor: "white",
                borderRadius: "10px",
                padding: "30px 20px",
                textAlign: "center",
                color: "#888",
                marginBottom: "20px"
              }}>
                Még nincsenek saját túrák
              </div>
            ) : (
              <div style={{ marginBottom: "20px" }}>
                {routes.map((route) => (
                  <Link 
                    key={route.id}
                    to={createPageUrl('Map') + '?routeId=' + route.id}
                    style={{ textDecoration: 'none', color: 'inherit', display: 'block', marginBottom: "15px" }}
                  >
                    <div style={{
                      backgroundColor: "white",
                      borderRadius: "10px",
                      display: "flex",
                      overflow: "hidden",
                      boxShadow: "0 2px 5px rgba(0,0,0,0.1)"
                    }}>
                      {route.image && (
                        <img 
                          src={route.image} 
                          alt={route.name}
                          style={{ width: "100px", height: "100px", objectFit: "cover" }}
                        />
                      )}
                      
                      <div style={{ padding: "15px", flex: 1 }}>
                        <h3 style={{ margin: "0 0 8px 0", fontSize: "16px", color: "#344E41", fontWeight: "bold" }}>
                          {route.name}
                        </h3>
                        <div style={{ display: "flex", gap: "10px", fontSize: "12px", color: "#888", flexWrap: "wrap" }}>
                          {route.distance && <span>📏 {route.distance} km</span>}
                          {route.duration && <span>⏱️ {route.duration}</span>}
                          {route.elevation && <span>⛰️ {route.elevation}m</span>}
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}

            <h2 style={{ fontSize: "18px", marginBottom: "15px", color: "#344E41" }}>
              Térképre mentett útvonalak ({trailRoutes.length})
            </h2>

            {trailRoutes.length === 0 ? (
              <div style={{
                backgroundColor: "white",
                borderRadius: "10px",
                padding: "30px 20px",
                textAlign: "center",
                color: "#888",
                marginBottom: "20px"
              }}>
                Még nincsenek mentett útvonalak
              </div>
            ) : (
              <div style={{ marginBottom: "20px" }}>
                {trailRoutes.map((route) => (
                  <Link 
                    key={route.id}
                    to={createPageUrl('Map') + '?trailRouteId=' + route.id}
                    style={{ textDecoration: 'none', color: 'inherit', display: 'block', marginBottom: "15px" }}
                  >
                    <div style={{
                      backgroundColor: "white",
                      borderRadius: "10px",
                      display: "flex",
                      overflow: "hidden",
                      boxShadow: "0 2px 5px rgba(0,0,0,0.1)"
                    }}>
                      <img 
                        src={route.image || "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&q=80"} 
                        alt={route.name}
                        style={{ width: "100px", height: "100px", objectFit: "cover" }}
                      />

                      <div style={{ padding: "15px", flex: 1 }}>
                        <h3 style={{ margin: "0 0 8px 0", fontSize: "16px", color: "#344E41", fontWeight: "bold" }}>
                          {route.name}
                        </h3>
                        <div style={{ display: "flex", gap: "10px", fontSize: "12px", color: "#888", flexWrap: "wrap" }}>
                          {route.distance && <span>📏 {route.distance} km</span>}
                          {route.duration && <span>⏱️ {route.duration}</span>}
                          {route.elevation && <span>⛰️ {route.elevation}m</span>}
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}

            <div style={{ padding: "0", display: "flex", gap: "10px" }}>
              <div style={{ flex: 1, backgroundColor: "white", padding: "15px", borderRadius: "10px", textAlign: "center" }}>
                <p style={{ fontSize: "20px", margin: 0, fontWeight: "bold", color: "#344E41" }}>
                  {routes.length}
                </p>
                <p style={{ fontSize: "12px", color: "#888", margin: "5px 0 0 0" }}>Útvonal</p>
              </div>
              <div style={{ flex: 1, backgroundColor: "white", padding: "15px", borderRadius: "10px", textAlign: "center" }}>
                <p style={{ fontSize: "20px", margin: 0, fontWeight: "bold", color: "#344E41" }}>
                  {routes.reduce((sum, r) => sum + (parseFloat(r.distance) || 0), 0).toFixed(1)}
                </p>
                <p style={{ fontSize: "12px", color: "#888", margin: "5px 0 0 0" }}>Össz. km</p>
              </div>
              <div style={{ flex: 1, backgroundColor: "white", padding: "15px", borderRadius: "10px", textAlign: "center" }}>
                <p style={{ fontSize: "20px", margin: 0, fontWeight: "bold", color: "#344E41" }}>
                  {routes.length > 0 ? routes[0].duration : '-'}
                </p>
                <p style={{ fontSize: "12px", color: "#888", margin: "5px 0 0 0" }}>Első túra</p>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}