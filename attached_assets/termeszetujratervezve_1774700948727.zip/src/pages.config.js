/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import BirdWatching from './pages/BirdWatching';
import BucketList from './pages/BucketList';
import Community from './pages/Community';
import Entertainment from './pages/Entertainment';
import Interactive from './pages/Interactive';
import Map from './pages/Map';
import NatureExplorer from './pages/NatureExplorer';
import Profile from './pages/Profile';
import Settings from './pages/Settings';
import TaskSheet from './pages/TaskSheet';
import WaterQualityProtocol from './pages/WaterQualityProtocol';
import WaterQualitySteps from './pages/WaterQualitySteps';
import ForestTaste from './pages/ForestTaste';
import __Layout from './Layout.jsx';


export const PAGES = {
    "BirdWatching": BirdWatching,
    "BucketList": BucketList,
    "Community": Community,
    "Entertainment": Entertainment,
    "Interactive": Interactive,
    "Map": Map,
    "NatureExplorer": NatureExplorer,
    "Profile": Profile,
    "Settings": Settings,
    "TaskSheet": TaskSheet,
    "WaterQualityProtocol": WaterQualityProtocol,
    "WaterQualitySteps": WaterQualitySteps,
    "ForestTaste": ForestTaste,
}

export const pagesConfig = {
    mainPage: "Map",
    Pages: PAGES,
    Layout: __Layout,
};