import React from 'react';
import { Link } from 'react-router-dom';

function createPageUrl(pageName) {
  return `/${pageName}`;
}

// this is the main layout that wraps all pages
// it adds the bottom navigation bar

export default function Layout({ children, currentPageName }) {
  
  // set page title
  React.useEffect(() => {
    document.title = "Természet újratervezve";
  }, []);
  
  // navigation menu items - new order with entertainment first
  let menuItems = [
    { page: "Entertainment", label: "Szórakozás", icon: "🎮" },
    { page: "Interactive", label: "Felfedezés", icon: "🧭" },
    { page: "Map", label: "Térkép", icon: "📍" },
    { page: "Community", label: "Közösség", icon: "👥" },
    { page: "Profile", label: "Profil", icon: "👤" }
  ];

  return (
    <div style={{ backgroundColor: "#DAD7CD", minHeight: "100vh" }}>
      
      {/* this is where the page content goes */}
      <main>
        {children}
      </main>

      {/* bottom navigation bar */}
      <div style={{
        position: "fixed",
        bottom: "20px",
        left: "20px",
        right: "20px",
        zIndex: 1000
      }}>
        <nav style={{
          backgroundColor: "#344E41",
          borderRadius: "15px",
          padding: "10px",
          display: "flex",
          justifyContent: "space-around"
        }}>
          {menuItems.map(function(item) {
            
            // check if this is the current page
            let isActive = currentPageName === item.page;
            
            return (
              <Link
                key={item.page}
                to={createPageUrl(item.page)}
                style={{
                  textDecoration: "none",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  padding: "8px 12px",
                  borderRadius: "10px",
                  backgroundColor: isActive ? "#588157" : "transparent"
                }}
              >
                <span style={{ fontSize: "18px" }}>{item.icon}</span>
                <span style={{
                  fontSize: "10px",
                  marginTop: "3px",
                  color: isActive ? "#DAD7CD" : "rgba(255,255,255,0.5)"
                }}>
                  {item.label}
                </span>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}